#ifndef TP_ALLOCATION_H
#define TP_ALLOCATION_H

void libere_mem(void *pt);

#endif
