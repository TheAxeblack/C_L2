#ifndef TP_ERREUR_H
#define TP_ERREUR_H

void mon_erreur(char *format, ...);

#endif
