#include <stdio.h>
#include <stdlib.h>

#ifndef TP_TP2_H
#define TP_TP2_H

void creer_tab(int taille);

void pascal(int x);

#endif
