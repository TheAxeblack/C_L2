/* Contenu : Fonctions trigonométriques
 * Date de creation : 16 February 2022
 * Author : Mathis Lecuyer
 */

#include <math.h>
#include "calculatrice.h"

double ft_cosinus(double x) {
    return cos(x);
}

double ft_sinus(double x) {
    return sin(x);
}

double ft_tangente(double x) {
    return tan(x);
}