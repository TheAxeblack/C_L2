#ifndef C_POSTFIXE_INVERSEE_H
#define C_POSTFIXE_INVERSEE_H

#include "arbre_binaire.h"

arbre creer_arbre_expression(char *expression, int *position);

int eval(arbre a);

#endif
