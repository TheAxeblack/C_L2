#ifndef C_USAGE_H
#define C_USAGE_H

#include <stdio.h>
#include <stdlib.h>

void ft_usage(char *name);

#endif
