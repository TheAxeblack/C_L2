#include <stddef.h>

#ifndef TP_ALLOCATION_H
#define TP_ALLOCATION_H

void libere_mem(void *pt);

void libere_mem_peda(void **pt);

void libere(void *pt);

#endif
