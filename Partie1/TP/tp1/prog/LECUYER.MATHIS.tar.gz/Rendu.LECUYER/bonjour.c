#include <stdio.h>
#include <stdlib.h>

int main(void){
  int a;
  int b;
  int c;

  a = 2;
  b = 3 * a;
  c = a + b;
  printf("bonjour: %d + %d = %d\n", a, b, c);
  exit(0);
}
