#include <stdlib.h>
#include <stdio.h>
#include "mod_lect.h"

void tri_bulle(tabPers *classeur);
