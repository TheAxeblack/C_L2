#include <stdlib.h>
#include <stdio.h>
#include "mod_tri.h"
#include "mod_recherche.h"

int main(){
  personne ind;
  tabPers classeur;
  sprintf(ind.nom, "Cule");
  sprintf(ind.prenom, "Jean");
  ind.num = 12502;

  lecture("registre.txt", &classeur);

  tri_bulle(&classeur);

  printf("\n");
  aff_tabPers(classeur);

  recherche_seq(classeur, ind);
  printf("\n");
  recherche_dic(classeur, ind);


  exit(0);
}
