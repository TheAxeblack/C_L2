#include "mod_tri.h"

void tri_bulle(tabPers *classeur){
  int i, j;
  personne temp;

  for(j = 0; j < classeur->nb_pers-1; j++){
    for(i = 0; i < classeur->nb_pers-1; i++){
      if (classeur->tab[i].nom[0] > classeur->tab[i+1].nom[0]){
        temp = classeur->tab[i];
        classeur->tab[i] = classeur->tab[i+1];
        classeur->tab[i+1] = temp;
      }
    }
  }
}
