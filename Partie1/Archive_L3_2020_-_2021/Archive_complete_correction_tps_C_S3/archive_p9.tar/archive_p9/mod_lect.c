#include "mod_lect.h"

/* Fonction répartissant les numeros, noms et prenoms dans des types personnes, la décomposition est plus optimisé */

void lecture(char* nom_fichier, tabPers *tab){
  FILE *fic = NULL;

  fic = fopen(nom_fichier, "r");
  if(fic == NULL){
    printf("Fichier non trouvé\n");
    exit(-1);
  }

  tab->nb_pers = 0;
  while(fscanf(fic, "%d %s %s", &tab->tab[tab->nb_pers].num, tab->tab[tab->nb_pers].nom, tab->tab[tab->nb_pers].prenom) == 3 && tab->nb_pers < MAX){
    tab->nb_pers++;
  }
}

void aff_tabPers(tabPers tab){
  int i;
  for(i = 0; i < tab.nb_pers; i++){
    printf("%d %s %s \n", tab.tab[i].num, tab.tab[i].nom, tab.tab[i].prenom);
  }
}

void aff_Pers(personne ind){
  printf("%d %s %s\n", ind.num, ind.nom, ind.prenom);
}
