#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void recherche_seq(tabPers classeur, personne ind);
void recherche_dic(tabPers classeur, personne ind);
