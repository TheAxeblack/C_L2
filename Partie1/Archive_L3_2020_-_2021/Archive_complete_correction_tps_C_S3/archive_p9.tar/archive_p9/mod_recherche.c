#include "mod_lect.h"
#include "mod_recherche.h"

int cmp_pers(personne individu1, personne individu2){
  if(!strcmp(individu1.nom, individu2.nom) && !strcmp(individu1.prenom, individu2.prenom) && individu1.num == individu2.num){
     return 1;
  }
  return 0;
}

void recherche_seq(tabPers classeur, personne ind){
  int i = 0, present = 0;
  while(i < classeur.nb_pers && !present){
    present = cmp_pers(classeur.tab[i], ind);
    i++;
  }
  if(present){
    printf("Personne présente dans le registre\n");
  }
  else{
    printf("Personne non trouvée\n");
  }
}


void recherche_dic(tabPers classeur, personne ind){
  int ecart = classeur.nb_pers/2, pos = ecart, present = 0;
  while(ecart > 0 && !present){
    ecart = ecart/2 + ecart%2;
    aff_Pers(classeur.tab[pos]);
    if(!cmp_pers(classeur.tab[pos], ind)){
      if(classeur.tab[pos].nom[0] > ind.nom[0]){
        pos -= ecart;
      }
      else{
        pos += ecart;
      }
    }
    else{
      present = 1;
    }
  }
  if(present){
    printf("Present dans le registre\n");
  }
  else{
    printf("Absent du registre\n");
  }
}
