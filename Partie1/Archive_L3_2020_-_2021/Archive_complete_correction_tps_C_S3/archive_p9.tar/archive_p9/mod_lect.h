#include <stdlib.h>
#include <stdio.h>
#define MAX 400

typedef struct{
  int num;
  char nom[30];
  char prenom[30];
}personne;

typedef struct{
  personne tab[MAX];
  int nb_pers;
}tabPers;

void lecture(char* nom_fichier, tabPers *tab);
void aff_tabPers(tabPers tab);
void aff_Pers(personne ind);
