#include <stdlib.h>
#include <stdio.h>

typedef struct heure heure;
struct heure{
  int h;
  int m;
  int s;
};

int h_to_s(heure h){
  int total;

  total = h.s + h.m*60 + h.h*3600;
  return total;
}

heure s_to_h(int secondes){
  heure montre;

  montre.h = secondes / 3600;
  secondes = secondes % 3600;

  montre.m = secondes / 60;
  secondes = secondes % 60;

  montre.s = secondes;

  return montre;
}

heure h_plus_h(heure montre_1, heure montre_2){
  heure montre_total;

  montre_total.s = montre_1.s + montre_2.s;
  montre_total.m = montre_1.m + montre_2.m + montre_total.s/60;
  montre_total.s = montre_total.s%60;

  montre_total.h = montre_1.h + montre_2.h + montre_total.m/60;
  montre_total.m = montre_total.m%60;

  return montre_total;
}

int main(){
  heure montre_1;
  int secondes;

  montre_1.h = 1;
  montre_1.m = 40;
  montre_1.s = 00;

  secondes = h_to_s(montre_1);
  printf("%d\n", secondes);

  heure montre_2 = s_to_h(6000);
  printf("%d %d %d\n", montre_2.h, montre_2.m, montre_2.s);

  heure montre_3 = h_plus_h(montre_1, montre_2);
  printf("%d %d %d\n", montre_3.h, montre_3.m, montre_3.s);

  secondes = h_to_s(montre_3);
  printf("%d\n", secondes);
  exit(0);
}
