#include <stdlib.h>
#include <stdio.h>

typedef struct complexe complexe;
struct complexe{
  float reel;
  float imag;
};

complexe plus(complexe z1, complexe z2){
  complexe z3;

  z3.reel = z1.reel + z2.reel;
  z3.imag = z1.imag + z2.imag;
  return z3;
}

complexe moins(complexe z1, complexe z2){
  complexe z3;

  z3.reel = z1.reel - z2.reel;
  z3.imag = z1.imag - z2.imag;
  return z3;
}

complexe fois(complexe z1, complexe z2){
  complexe z3;

  z3.reel = z1.reel*z2.reel - z1.imag*z2.imag;
  z3.imag = z1.reel*z1.imag + z2.reel*z2.imag;
  return z3;
}

complexe divise(complexe z1, complexe z2){
  complexe z3;

  z3.reel = (z1.reel*z2.reel - z1.imag*z2.imag)/(z2.reel*z2.reel + z2.imag*z2.imag);
  z3.imag = (z1.reel*z1.imag - z2.reel*z2.imag)/(z2.reel*z2.reel + z2.imag*z2.imag);
  return z3;
}

int main(){
  complexe z1, z2, z3, z4, z5, z6;

  z1.reel = 2;
  z1.imag = 4;

  z2.reel = -4;
  z2.imag = 8;

  z3 = plus(z1, z2);
  printf("%f+%fi\n", z3.reel, z3.imag);

  z4 = moins(z1, z2);
  printf("%f+%fi\n", z4.reel, z4.imag);

  z5 = fois(z1, z2);
  printf("%f+%fi\n", z5.reel, z5.imag);

  z6 = divise(z1, z2);
  printf("%f+%fi\n", z6.reel, z6.imag);
  exit(0);
}
