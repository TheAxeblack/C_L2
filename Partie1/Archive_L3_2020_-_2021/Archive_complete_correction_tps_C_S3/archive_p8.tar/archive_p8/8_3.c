#include <stdlib.h>
#include <stdio.h>
#include <time.h>

typedef struct participant{
  char nom[30];
  char prenom[20];
  int repas;
  int hotel;
  int conjoint;
}particiant;

typedef particiant tabPart[100];

void afficher_tab(tabPart tab){
  int i;
  for(i = 0; i < 100; i++)
    printf("%c, %c, %d, %d, %d\n", tab[i].nom[0], tab[i].prenom[0], tab[i].repas, tab[i].hotel, tab[i].conjoint);
}

void init_tabPart(tabPart tab){
  int i;

  srand(time(NULL));

  for(i = 0; i < 100; i++){
    tab[i].nom[0] = (char)90-rand()%26;
    tab[i].prenom[0] = (char)122-rand()%26;
    tab[i].repas = 15*(rand()%2) + 35*(rand()%2);
    tab[i].hotel = 3-rand()%2;
    tab[i].conjoint = rand()%2;
  }
}

void nb2etoiles(tabPart tab){
  int i;
  for(i = 0; i < 100; i++){
    if (tab[i].hotel == 2)
      printf("%c, %c, %d\n", tab[i].nom[0], tab[i].prenom[0], tab[i].hotel);
  }
}

void nbDej(tabPart tab){
  int i;
  for(i = 0; i < 100; i++){
    if ((tab[i].repas == 15) || (tab[i].repas == 50))
      printf("%c, %c, %d\n", tab[i].nom[0], tab[i].prenom[0], tab[i].repas);
  }
}

void montant(tabPart tab){
  int i;
  for(i = 0; i < 100; i++)
    printf("la facture de %c.%c. est de %d €\n", tab[i].nom[0], tab[i].prenom[0], tab[i].repas*(tab[i].conjoint+1) + 75 + 25*(tab[i].hotel-2));
}

int main(){
  tabPart tab;

  init_tabPart(tab);

  nb2etoiles(tab);
  nbDej(tab);
  montant(tab);
  exit(0);
}
